<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Persona extends Model
{
    use HasFactory;
    
    //tabla del modelo: bikes
    protected $table = 'persona';
    public $timestamps = false;
    
    protected $fillable = ['dni','nombre','apellidos','telefono'];
}