<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\StoreRequest;

class PostController extends Controller
{
    //
    public function index(){
       $posts = Post::all();
        $id = Auth::id();
        return view('Blog.show',['activePosts'=> 'active','posts' => $posts, 'subTitle'=> 'Posts - Index', 'id'=>$id]);
    }
    public function update(StoreRequest $request,$id){
        $post = Post::find($id);
        $post->update($request->all());
        return redirect('home');
    }
    public function create(){
        $id = Auth::id();
        return view('Blog.create',['id' => $id]);
    }
    public function store(StoreRequest $request){
        $post = new Post($request->all());
        $post-> save();
        
        return redirect('home');
    }
    public function edit(Post $post){
        return view('Blog.edit', ['post' => $post]);
    }
    public function delete($id){
        $post = Post::find($id);
        $post->delete();
        return redirect('home');
    }
}
