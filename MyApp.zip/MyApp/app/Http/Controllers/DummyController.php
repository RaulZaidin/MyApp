<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DummyController extends Controller
{
    function any(Request $request){//any method
    $metodo= $request->method();
        return 'any, has llegado con el metodo: ' . $metodo;
    }
    function delete(){//delete method
        return 'delete';
    }
    function get(){
       // return 'get: '.csrf_token();
       return view('dummy.get');
    }
    function post(){
        return 'post';
    }
    function put(){
        return 'put';
    }
}
