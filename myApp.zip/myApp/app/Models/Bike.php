<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Bike extends Model
{
    use HasFactory;
    
    //tabla del modelo: bikes
    protected $table = 'bike';
    //public $timestamps = false;
    
    protected $fillable = ['name'];
}
