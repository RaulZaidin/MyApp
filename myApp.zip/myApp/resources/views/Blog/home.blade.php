@extends('Blog.app')

@section('content')

    <div class="container" style="width:700px; height:500px; margin-top:70px; padding:0">
        <div style="border:1px solid black; width:100%; height:125px; background-color:#eda46f">
            <h2>Mis publicaciones</h2>
        </div>
        <div style="border:1px solid black; width:100%; height:125px; background-color:#eda46f">
            <h2>Crear publicación</h2>
        </div>
        <div style="border:1px solid black; width:100%; height:125px; background-color:#eda46f">
            <h2>Editar publicación</h2>
        </div>
        <div style="border:1px solid black; width:100%; height:125px; background-color:#eda46f">
            <h2>Borrar publicación</h2>
        </div>
    </div>

@endsection